<?php

namespace PenciPaywall\Payments\Stripe\Lib\Exception\OAuth;

/**
 * The base interface for all Stripe OAuth exceptions.
 */
interface Exception_Interface extends PenciPaywall\Payments\Stripe\Lib\Exception\Exception_Interface
{

}
