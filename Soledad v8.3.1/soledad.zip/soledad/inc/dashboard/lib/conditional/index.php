<?php

// Silence is golden